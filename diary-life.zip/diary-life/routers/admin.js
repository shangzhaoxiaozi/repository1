const router = require('koa-router')();
const controller = require('../controller/c-admin')

router.get('/admin', controller.getSignin1)
router.post('/admin', controller.postSignin1)

module.exports = router