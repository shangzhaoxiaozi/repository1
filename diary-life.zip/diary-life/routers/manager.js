const router = require('koa-router')();
const controller = require('../controller/c-manager')


router.get('/manager', controller.getSignin2)
router.post('/manager', controller.postSignin2)


module.exports = router