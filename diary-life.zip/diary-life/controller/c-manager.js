const userModel = require('../lib/mysql.js');

const checkNotLogin = require('../middlewares/check.js').checkNotLogin
const checkLogin = require('../middlewares/check.js').checkLogin
const moment = require('moment');
const fs = require('fs')

exports.getSignin2 = async ctx => {
    // await checkNotLogin(ctx)//******************拦截登陆
    // await ctx.render('manager', {
    //     session: ctx.session,
    // })

    let res
    // postsLength,
    // name = decodeURIComponent(ctx.request.querystring.split('=')[1]);
    if (1) {
        await userModel.findAllUser()
            .then(result => {
                res = result;
            })

        await ctx.render('manager', {
            session: ctx.session,
            posts: res,
            // postsPageLength: Math.ceil(postsLength / 10),
        })
    } else {
        console.log("hahahaha")
    }
}
//******************attention
// exports.postSignin2 = async ctx => {
//
//     console.log("8888888888888888888")
//     let { id,name}  = ctx.request.body
//     console.log(name+"99999999999999999")
//
//     if (1) {
//
//         await userModel.deleteUserData(name)
//             .then(() => {
//                 ctx.body = {
//                     code: 200,
//                     message: '删除用户成功'
//                 }
//             }).catch(() => {
//                 ctx.body = {
//                     code: 500,
//                     message: '删除用户失败'
//                 }
//             })
//     } else {
//         ctx.body = {
//             code: 404,
//             message: '无权限'
//         }
//     }
//
// }



exports.postSignin2 = async ctx => {
    console.log(ctx.request.body)
    let name = ctx.request.body
    await userModel.deleteUserData(name)
        .then(result => {
            let res = result
            if (res.length && name === res[0]['name'] && md5(password) === res[0]['pass']) {
                ctx.session = {
                    user: res[0]['name'],
                    id: res[0]['id']
                }
                // ctx.body = {
                //     code: 200,
                //     message: '登录成功'
                // }
                console.log('ctx.session.id', ctx.session.id)
                console.log('session', ctx.session)
                console.log('删除成功')
            } else {
                console.log('删除错误!')
            }
        }).catch(err => {
            console.log(err)
        })

}