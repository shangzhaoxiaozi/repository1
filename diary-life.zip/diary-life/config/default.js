const config = {
  // 启动端口
  port: 3000,
  // 数据库配置
  database: {
    DATABASE: 'nodesql',
    USERNAME: 'root',
    PASSWORD: '19881201',
    PORT: '3306',
    HOST: 'localhost'
  }
}

module.exports = config